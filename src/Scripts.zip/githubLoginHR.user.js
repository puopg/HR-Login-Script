// ==UserScript==
// @name        githubLoginHR
// @include     http://bookstrap.hackreactor.com/auth/login
// @version     1.0
// @require     http://ajax.aspnetcdn.com/ajax/jquery/jquery-1.8.0.js
// ==/UserScript==
$( document ).ready(function() {
    var d = new Date();
	var n = d.getHours();
    // TODO: perhaps find a different way to handle the flag to login or not
    sessionStorage.setItem("needsLogin", "false");
    
    // TODO: for now, this only works between 8 and 10 AM
    if(n > 7 && n < 10)
    {
    	// Notify we need to login
    	sessionStorage.setItem("needsLogin", "true");
    
    	console.log("Logging into github");
        
    	// click the button
        // TODO: need to have a more robust or flexible way to get the button!
        // currently no error checking
	    $("a[href$='/auth/github']")[0].click();  
    }
    else {
        console.log("For now, log in only works between 8AM and 10 AM");
    }
});