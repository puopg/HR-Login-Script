// ==UserScript==
// @name        readyToLearnHR
// @include     http://bookstrap.hackreactor.com/attendance
// @version     1.0
// @require     http://ajax.aspnetcdn.com/ajax/jquery/jquery-1.8.0.js
// ==/UserScript==
$( document ).ready(function() {
    // Check if we need to login
    var needsLogin = sessionStorage.getItem("needsLogin");
    
    console.log("needsLogin: " + needsLogin);
    if(needsLogin === "true"){
		// press "I'm ready to learn!"
        setTimeout(function(){
            console.log("Pressing Im ready to learn button");
            $('.ready-to-learn').click();
        },5000)
        
        sessionStorage.setItem("needsLogin", "false");
        // TODO: where does the user go after?
    }
    else{
        console.log("needsLogin: " + needsLogin);
    }
});